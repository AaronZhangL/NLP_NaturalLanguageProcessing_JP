#
# Copyright(C) 2007-2012 National Institute of Information and Communications Technology
#

dir=`cd $(dirname $0) && pwd`

# 中間ファイルを一時的に保存するディレクトリ
export TMPDIR=/tmp
#export TMPDIR=$dir/tmp

# モデルファイルのプレフィックス
export model=$dir/modeldata/model/model
#export model=$dir/modeldata/sample/model
#model=$dir/modeldata/make/model

#辞書のディレクトリ
export dictionary=$dir/dic

# 必要に応じて，CRF++, nkf, gawk, perl, JUMAN, KNPのパスを設定
#export PATH=


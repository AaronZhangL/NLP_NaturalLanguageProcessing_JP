#!/bin/sh

#堀内作成
#金澤awk化
#
# jumanとknpでやっていることを、cabocha(mecab)の処理とawkの整形で実装
# 入力値は1行が長すぎると処理が重くなるので、句点単位で改行した文章。
# cabochaの結果としては、以下のようになる
#
#* 0 -1D 2/2 0.000000
#早大  名詞,固有名詞,組織,*,*,*,早大,ソウダイ,ソーダイ B-ORGANIZATION
#３  名詞,数,*,*,*,*,３,サン,サン  O   
#連覇  名詞,サ変接続,*,*,*,*,連覇,レンパ,レンパ  O   
#EOS
#* 0 1D 0/1 0.550072
#斎藤  名詞,固有名詞,人名,姓,*,*,斎藤,サイトウ,サイトー  B-PERSON
#が  助詞,格助詞,一般,*,*,*,が,ガ,ガ O
#* 1 2D 3/3 0.000000
#１  名詞,数,*,*,*,*,１,イチ,イチ  O   
#５  名詞,数,*,*,*,*,５,ゴ,ゴ  O   
#奪  接頭詞,名詞接続,*,*,*,*,奪,ダツ,ダツ  O   
#三振  名詞,サ変接続,*,*,*,*,三振,サンシン,サンシン  O   
#、  記号,読点,*,*,*,*,、,、,、  O   
#* 2 -1D 1/1 0.000000
#初  接頭詞,名詞接続,*,*,*,*,初,ハツ,ハツ  O   
#完封  名詞,サ変接続,*,*,*,*,完封,カンプウ,カンプー  O   
#EOS
#
# 上記cabochaの結果を読んで、１行１文にまとめたものを返す
#
jumandic="../../gzArchive/jumandic";
cat $1|nkf -wLu|nkf -We |grep -v "^$"| cabocha -f1 -d "$jumandic"|nkf -wLu | awk '
BEGIN{
    count=1;
    surface="";
    parts="";
    parts_detail="";
    clauseno="";
    charno="";
    has="";
    depend="";
    sentence="0";
    wordcnt="0";
}{
  if ( $0 ~ /^\*/ ) {
    cln = $2 ;
    hs = $3 ;
    gsub ( /D/, "", hs);
    if ( clauseno == "" ){
      clauseno = cln ;
    } else {
      clauseno = clauseno "_" cln ;
    }
    if ( has == "" ){
      has = hs ;
    } else {
      has = has "_" hs ;
    }
    wordcnt++ ;
    if ( count == 0 ) { next ; }
    if ( charno == "" ){
      charno = count ;
    } else {
      charno = charno "_" count ;
    }
  } else if ( $0 ~ /EOS/ ) {
    sentence = 1;
    words = surface ;
    gsub ( /_/, "", words );
    for ( i = 1; i <= wordcnt; i++){
      if ( i == 1 ) {
        dcnt = "D";
      }else{
        dcnt = dcnt "_D" ;
      }
    } # for i end
    gsub ( /-1/, "0", has) ;
    gsub ( /^1_/, "", charno);
    charno = charno "_" count ;
    result = sentence "|" words "|" surface ":" surface2 ":" parts ":" parts_detail "	" charno ":" has ":" dcnt ;
    #results[num] = result ;
	  results=results "\n" result;
    clauseno="";
    charno="";
    has="";
    surface="";
    surface2="";
    parts="";
    parts_detail="";
    count="1";
    wordcnt="0";
    dcnt="";
  } else {
    sf = $1;
    split($2, sf_arr, ",");
    ps = sf_arr[1];
    psd = sf_arr[2];
    sf2 = sf_arr[5] ;
    if ( surface == "" ){
      surface = sf ;
    } else {
      surface = surface "_" sf ;
    }
    if ( sf2 == "*" ) {
      sf2 = sf ;
    }
    if ( surface2 == "" ){
      surface2 = sf2 ;
    } else {
      surface2 = surface2 "_" sf2 ;
    }
    if ( parts == "" ){
      parts = ps ;
    } else {
      parts = parts "_" ps ;
    }
    if ( parts_detail == "" ){
      parts_detail = psd ;
    } else {
      parts_detail = parts_detail "_" psd ;
    }
    count++ ;
  }
}END{
  print results ;
}'

#!/bin/sh

#
# Copyright(C) 2007-2012 National Institute of Information and Communications Technology
#

export LANG=C

dir=`cd $(dirname $0) && pwd`

. $dir/conf.sh

export EXOPLIB=$dir/lib

cat $dir/makemodel/tsv/*.tsv > $dir/makemodel/data.tsv
cat $dir/makemodel/data.tsv > $dir/makemodel/data_pol.tsv

$dir/_train.sh makemodel/model/model $dir/makemodel/data.tsv $dir/makemodel/data.tsv $dir/makemodel/data.tsv $dir/makemodel/data_pol.tsv $dir/makemodel/data.tsv
rm $dir/makemodel/data.tsv $dir/makemodel/data_pol.tsv






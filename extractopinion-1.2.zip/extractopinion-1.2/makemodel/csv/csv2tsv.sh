#!/bin/sh
#!/usr/bin/env perl

#
# Copyright(C) 2007-2012 National Institute of Information and Communications Technology
#

for f in *.csv
do
  f=`basename $f .csv`
  perl -I ../../lib ./csv2tsv.pl $f.csv > ../tsv/$f.tsv
done








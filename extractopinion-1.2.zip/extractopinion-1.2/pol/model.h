/*
  Copyright(C) 2007-2012 National Institute of Information and Communications Technology
*/

/*
  Model Module
*/


#include <stdio.h>
#include "hashtable.h"


#ifndef _MODEL_H_
#define _MODEL_H_


/*
  $B%b%G%k(B
*/
typedef struct Mdl {
  SDB *ft;		/* $BAG@-%F!<%V%k(B */
  double *lmd;		/* $BAG@-$N=E$_(B */
} MDL;


MDL *mdl_new(void);
MDL *mdl_read(FILE *fp);
int mdl_write(MDL *mdl, FILE *fp);
#if 0
double mdl_score(MDL *mdl, int fv_num, int *fv);
void mdl_fvsub(int a_num, int *a, int b_num, int *b, int *c_num, int *c_idx, short *c_val, short *lut);
int mdl_addftr(SDB *ft, int *fv_num, int *fv, int flag, ...);
#endif


#endif

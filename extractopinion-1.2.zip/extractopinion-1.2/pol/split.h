/*
  Copyright(C) 2007-2012 National Institute of Information and Communications Technology
*/

/*
  Split library
*/


#ifndef _SPLIT_H_
#define _SPLIT_H_


#include <stddef.h>


size_t split(char *str, char del, char **ptr, size_t size);


#endif

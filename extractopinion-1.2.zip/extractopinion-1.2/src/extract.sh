#!/bin/sh

#
# Copyright(C) 2007-2012 National Institute of Information and Communications Technology
#

if [ $# -ne 4 ]
then
  echo "usage: test.sh <*.ft> <*.svmmdl> <*.crfmdl> <*.tsv>" 1>&2
  exit 1
fi

dir=`dirname $0`
tmp=${TMPDIR:-.}
ftfile=$1
svmmdlfile=$2
crfmdlfile=$3
tsvfile=$4
tmptsvfile=$tmp/test.$$.tsv

$dir/svmtest.sh $ftfile $svmmdlfile $tsvfile > $tmptsvfile
$dir/crftest.sh $crfmdlfile $tmptsvfile

rm -f $tmptsvfile


#!/bin/sh

#
# Copyright(C) 2007-2012 National Institute of Information and Communications Technology
#

if [ $# -ne 4 ]
then
  echo "usage: train.sh <*.ft> <*.svmmdl> <*.crfmdl> <*.tsv>" 1>&2
  exit 1
fi

dir=`dirname $0`
ftfile=$1
svmmdlfile=$2
crfmdlfile=$3
tsvfile=$4

$dir/svmtrain.sh $ftfile $svmmdlfile < $tsvfile
$dir/crftrain.sh $crfmdlfile < $tsvfile
